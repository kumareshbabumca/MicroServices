package app.service;

import app.domain.User;

import java.util.List;


public interface UserService {

    public List<User> selectUserList();

    public User selectUserById(String id);

    public void insertUser(User user);

    public void updateUser(String id, User user);

    public void deleteUser(String id);

}
